/*
Write a program that initializes 2 byte type of variables. 
Add the values of these variables and store in a byte type of variable. 
[Note: primitive down casting is required in this program ] . 
 */
package OOPS.Assignments.Assignment1.Assignment1;

public class program4 {
    public static void main(String[] args)
    {
        byte x=8,y=8,z;
        z=(byte)(x+y);
         System.out.println(z);
        
    }
    
}
