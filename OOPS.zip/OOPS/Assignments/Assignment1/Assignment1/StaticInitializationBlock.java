/*
Write a program to read the days (eg. 670 days) as integer value using Scanner class. 
Now convert the entered days into complete years, months and days and print them.
 */
package OOPS.Assignments.Assignment1.Assignment1;


public class StaticInitializationBlock {
    static{
System.out.println("Static block");
 System.exit(0);
}
    
}
