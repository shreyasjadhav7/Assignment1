/*	Write a program to print Hello World.
Compile and run it using command prompt. */

package OOPS.Assignments.Assignment1.Assignment1;

public class program1 {
    public static void main(String[] args)
    {
        System.out.println("Hello World!");
    }
}
