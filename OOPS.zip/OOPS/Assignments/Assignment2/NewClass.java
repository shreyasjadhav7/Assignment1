/*
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */
package OOPS.Assignments.Assignment2;

/**
 *
 * @author naman
 */
public class NewClass {
    public static void main(String[] args)
    {
       
        int i=245;
        byte b=(byte)i;
         System.out.println(b);
        
        
    }
    
}
